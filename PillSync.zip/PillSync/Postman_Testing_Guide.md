# Postman Testing Guide — PillSync Authentication APIs

This document outlines the requests, parameters, payloads, and expected responses for verification in Postman.

---

## 1. User Registration

### 1A. Successful Patient Registration
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/register/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "username": "testpatient",
      "email": "patient@example.com",
      "password": "PatientPassword@123",
      "first_name": "John",
      "last_name": "Patient",
      "phone_number": "1234567890",
      "role": "PATIENT"
  }
  ```
- **Expected Status**: `201 Created`
- **Expected Response**:
  ```json
  {
      "id": 1,
      "username": "testpatient",
      "email": "patient@example.com",
      "first_name": "John",
      "last_name": "Patient",
      "phone_number": "1234567890",
      "role": "PATIENT",
      "created_at": "2026-08-30T13:50:26.684950Z",
      "updated_at": "2026-08-30T13:50:26.684959Z"
  }
  ```

### 1B. Fail: Duplicate Username
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/register/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**: (Same username, different email)
  ```json
  {
      "username": "testpatient",
      "email": "another@example.com",
      "password": "StrongPassword@123",
      "first_name": "Dup",
      "last_name": "User",
      "role": "PATIENT"
  }
  ```
- **Expected Status**: `400 Bad Request`
- **Expected Response**:
  ```json
  {
      "username": [
          "A user with that username already exists."
      ]
  }
  ```

### 1C. Fail: Duplicate Email
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/register/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**: (Different username, same email)
  ```json
  {
      "username": "anotheruser",
      "email": "patient@example.com",
      "password": "StrongPassword@123",
      "first_name": "Dup",
      "last_name": "User",
      "role": "PATIENT"
  }
  ```
- **Expected Status**: `400 Bad Request`
- **Expected Response**:
  ```json
  {
      "email": [
          "user with this email already exists."
      ]
  }
  ```

### 1D. Fail: Weak Password
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/register/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "username": "weakuser",
      "email": "weak@example.com",
      "password": "short",
      "first_name": "Weak",
      "last_name": "User",
      "role": "PATIENT"
  }
  ```
- **Expected Status**: `400 Bad Request`
- **Expected Response**:
  ```json
  {
      "password": [
          "This password is too short. It must contain at least 8 characters."
      ]
  }
  ```

### 1E. Fail: Missing Required Fields
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/register/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**: (Missing `first_name` and `last_name`)
  ```json
  {
      "username": "missingfields",
      "email": "missing@example.com",
      "password": "StrongPassword@123",
      "role": "PATIENT"
  }
  ```
- **Expected Status**: `400 Bad Request`
- **Expected Response**:
  ```json
  {
      "first_name": [
          "This field is required."
      ],
      "last_name": [
          "This field is required."
      ]
  }
  ```

---

## 2. Login with JWT

### 2A. Successful Login
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/login/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "username": "testpatient",
      "password": "PatientPassword@123"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "refresh": "<REFRESH_TOKEN>",
      "access": "<ACCESS_TOKEN>"
  }
  ```

### 2B. Fail: Wrong Password
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/login/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "username": "testpatient",
      "password": "WrongPassword@123"
  }
  ```
- **Expected Status**: `401 Unauthorized`
- **Expected Response**:
  ```json
  {
      "detail": "No active account found with the given credentials"
  }
  ```

---

## 3. JWT Token Refresh

### 3A. Successful Refresh
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/token/refresh/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "refresh": "<REFRESH_TOKEN>"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "access": "<NEW_ACCESS_TOKEN>",
      "refresh": "<NEW_REFRESH_TOKEN_IF_ROTATED>"
  }
  ```

### 3B. Fail: Expired/Invalid Refresh Token
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/token/refresh/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "refresh": "invalid_or_expired_token_value"
  }
  ```
- **Expected Status**: `401 Unauthorized`
- **Expected Response**:
  ```json
  {
      "detail": "Token is invalid",
      "code": "token_not_valid"
  }
  ```

---

## 4. Authenticated User Details (GET Profile)

### 4A. Successful Fetch
- **Method**: `GET`
- **URL**: `http://localhost:8000/api/auth/me/`
- **Headers**:
  - `Authorization`: `Bearer <ACCESS_TOKEN>`
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "id": 1,
      "username": "testpatient",
      "email": "patient@example.com",
      "first_name": "John",
      "last_name": "Patient",
      "phone_number": "1234567890",
      "role": "PATIENT",
      "created_at": "2026-08-30T13:50:26.684950Z",
      "updated_at": "2026-08-30T13:50:26.684959Z"
  }
  ```

### 4B. Fail: Unauthorized (Invalid Token)
- **Method**: `GET`
- **URL**: `http://localhost:8000/api/auth/me/`
- **Headers**:
  - `Authorization`: `Bearer invalid_token_here`
- **Expected Status**: `401 Unauthorized`
- **Expected Response**:
  ```json
  {
      "detail": "Given token not valid for any token type",
      "code": "token_not_valid",
      "messages": [
          {
              "token_class": "AccessToken",
              "token_type": "access",
              "message": "Token is invalid or expired"
          }
      ]
  }
  ```

### 4C. Fail: Unauthorized (No Token)
- **Method**: `GET`
- **URL**: `http://localhost:8000/api/auth/me/`
- **Headers**: (None)
- **Expected Status**: `401 Unauthorized`
- **Expected Response**:
  ```json
  {
      "detail": "Authentication credentials were not provided."
  }
  ```

---

## 5. Change Password

### 5A. Successful Change
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/change-password/`
- **Headers**:
  - `Authorization`: `Bearer <ACCESS_TOKEN>`
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "old_password": "PatientPassword@123",
      "new_password": "NewStrongPassword@123"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "detail": "Password has been updated successfully."
  }
  ```

### 5B. Fail: Incorrect Old Password
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/change-password/`
- **Headers**:
  - `Authorization`: `Bearer <ACCESS_TOKEN>`
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "old_password": "WrongOldPassword@123",
      "new_password": "NewStrongPassword@123"
  }
  ```
- **Expected Status**: `400 Bad Request`
- **Expected Response**:
  ```json
  {
      "old_password": [
          "Old password is incorrect."
      ]
  }
  ```

---

## 6. Password Reset Workflow

### 6A. Trigger Password Reset Link
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/password-reset/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "email": "patient@example.com"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response** (Console prints email and API returns tokens in JSON for dev ease):
  ```json
  {
      "detail": "Password reset email has been sent.",
      "dev_info": {
          "uidb64": "MQ",
          "token": "de51q5-78078fcf62314502acdf7925207610f9",
          "reset_url": "http://localhost:8000/api/auth/password-reset/confirm/?uidb64=MQ&token=de51q5-78078fcf62314502acdf7925207610f9"
      }
  }
  ```

### 6B. Confirm Password Reset
- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/password-reset/confirm/`
- **Headers**:
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "uidb64": "MQ",
      "token": "de51q5-78078fcf62314502acdf7925207610f9",
      "new_password": "ResetPatientPassword@123"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "detail": "Password has been reset successfully."
  }
  ```

---

## 7. Logout / Token Invalidation

- **Method**: `POST`
- **URL**: `http://localhost:8000/api/auth/logout/`
- **Headers**:
  - `Authorization`: `Bearer <ACCESS_TOKEN>`
  - `Content-Type`: `application/json`
- **Body (JSON)**:
  ```json
  {
      "refresh": "<REFRESH_TOKEN>"
  }
  ```
- **Expected Status**: `200 OK`
- **Expected Response**:
  ```json
  {
      "detail": "Successfully logged out and token invalidated."
  }
  ```

---

## 8. OAuth2 Authentication

Django OAuth Toolkit provides standard endpoints:
- Authorization Code Endpoint: `/api/oauth/authorize/`
- Token Endpoint: `/api/oauth/token/`
- Token Revocation Endpoint: `/api/oauth/revoke/`

### How to configure and test OAuth2:

1. **Create an OAuth2 Application in Admin Console**:
   - Log into the django administration panel (`http://localhost:8000/admin/`).
   - Scroll to **Django OAuth Toolkit** -> **Applications** -> **Add Application**.
   - Fill in:
     - `Client id`: (automatically generated)
     - `Client secret`: (automatically generated)
     - `User`: Select your superuser.
     - `Client type`: `Confidential`
     - `Authorization grant type`: `Resource owner password-based` (or `Authorization code`)
     - `Redirect uris`: `http://localhost:8000/`
     - `Name`: `PillSync Web Client`
   - Click **Save**.

2. **Obtain Token via Resource Owner Password Flow in Postman**:
   - **Method**: `POST`
   - **URL**: `http://localhost:8000/api/oauth/token/`
   - **Headers**:
     - `Content-Type`: `application/x-www-form-urlencoded`
   - **Body (x-www-form-urlencoded)**:
     - `grant_type`: `password`
     - `username`: `testpatient`
     - `password`: `PatientPassword@123` (or current password)
     - `client_id`: `<YOUR_CLIENT_ID_FROM_ADMIN>`
     - `client_secret`: `<YOUR_CLIENT_SECRET_FROM_ADMIN>`
   - **Expected Status**: `200 OK`
   - **Expected Response**:
     ```json
     {
         "access_token": "<OAUTH2_ACCESS_TOKEN>",
         "expires_in": 3600,
         "token_type": "Bearer",
         "scope": "read write",
         "refresh_token": "<OAUTH2_REFRESH_TOKEN>"
     }
     ```
