# PillSync — Authentication & Database Schema (Milestone 1)

This project contains the implementation of **Task 2: Authentication Workflows** and **Task 3: Database Schema** for PillSync, an Intelligent Medicine Reminder and Medication Tracking Platform.

---

## What Has Been Implemented (Scope of My Assignment)

### Task 2: Authentication Workflows
- **User Registration**: `POST /api/auth/register/` (Validates inputs, prevents duplicate usernames/emails, enforces django-level password rules, hashes password, and automatically generates profiles).
- **JWT Authentication Login**: `POST /api/auth/login/` (Accepts username and password, returns access and refresh tokens via SimpleJWT).
- **JWT Token Refresh**: `POST /api/auth/token/refresh/` (Validates refresh token and returns a new access token).
- **Session Authentication**: Configured standard Django session management via middleware and default DRF authentication to support session cookies in browser clients and Django administration views.
- **Logout/Token Invalidation**: `POST /api/auth/logout/` (Blacklists simplejwt refresh tokens to securely terminate the session).
- **Protected User Profile**: `GET /api/auth/me/` (Returns authenticated user profile details to prove token validation).
- **Secure Password Update**: `POST /api/auth/change-password/` (Verifies old password, validates strength of new password, hashes and updates it).
- **Secure Password Reset**:
  - `POST /api/auth/password-reset/` (Accepts email, generates token + uidb64, sends simulated email to console in development).
  - `POST /api/auth/password-reset/confirm/` (Accepts token, uidb64, and new password, validates inputs and resets password).
- **OAuth2 Configuration**: Integrated `django-oauth-toolkit` (DOT) with migrations, config, and router mappings at `/api/oauth/` to enable future third-party application clients.

### Task 3: Database Schema (PostgreSQL-Compatible)
- **User & Profiles**:
  - `User`: Custom user table extending `AbstractUser` to support email uniqueness, `phone_number`, and `role` (`PATIENT`, `CAREGIVER`, `ADMIN`).
  - `PatientProfile`: One-to-one relationship with `User` storing date of birth, gender, address, emergency contact.
  - `CaregiverProfile`: One-to-one relationship with `User`.
  - `PatientCaregiver`: Caregiver-to-Patient bridge table with a `unique_together` constraint on `('patient', 'caregiver')` to avoid duplicate links.
- **Medications & Schedules**:
  - `Medicine`: Connects to `PatientProfile` (CASCADE deletion), storing medicine details.
  - `MedicationSchedule`: Connects to `Medicine` (CASCADE deletion), storing scheduled time, frequency, and active state.
  - `Prescription`: Connects to `PatientProfile` (CASCADE deletion), storing upload details and file paths.
  - `MedicationHistory`: Connects to both `Medicine` and `PatientProfile` (CASCADE deletion), tracking dosage logs (status: `TAKEN`, `MISSED`, `SKIPPED`), taken timestamps, and remarks.

---

## What Is Intentionally NOT Implemented (Other Team Members' Tasks)
- **Role-Based Access Control (RBAC) View Logic**: No view restrictions are enforced (e.g. `IsPatient`, `IsCaregiver`) as that belongs to the RBAC team.
- **Medicine Management Business Logic**: CRUD endpoints for medicines and scheduling are omitted.
- **AI Refill Prediction, OCR, Reminders, Push Notifications**: Intentionally omitted.
- **Frontend Code**: No React files are included.
- **PostgreSQL Setup/Infrastructure**: Database installation and Docker container setup are omitted (configured to connect dynamically via environment variables).

---

## Authentication Architecture

PillSync utilizes a hybrid authentication approach:
1. **JWT (JSON Web Tokens)**: Primary mechanism for stateless API client authentication. Tokens are signed via `HS256` using the application's `SECRET_KEY`.
2. **Session Cookies**: Standard Django sessions are supported for browser interfaces, DRF browsable API, and administrative dashboard.
3. **OAuth2 (Resource Owner / Client Credentials)**: Provided via Django OAuth Toolkit for potential external integrations.

### JWT Token Workflow

```
[ Client ]                             [ Django API Server ]
    |                                            |
    | ----- 1. POST /api/auth/login/ ----------> | (Verifies credentials)
    | <---- 2. Returns Access & Refresh ---------| (Tokens issued)
    |                                            |
    | -- 3. GET /api/auth/me/ (Bearer Access) -> | (Validates Access Token)
    | <---- 4. Returns User Profile Data --------|
    |                                            |
    | -- 5. POST /api/auth/token/refresh/ -----> | (Validates Refresh Token)
    | <---- 6. Returns New Access Token ---------| (Rotates old refresh token)
    |                                            |
    | ----- 7. POST /api/auth/logout/ ---------> | (Blacklists Refresh Token)
    | <---- 8. Returns Logout Success -----------|
```

---

## Database Schema & Relationships

The database schema is fully normalized and complies with PostgreSQL conventions. It is visualised below:

```mermaid
erDiagram
    User ||--o| PatientProfile : "has PatientProfile (1:1)"
    User ||--o| CaregiverProfile : "has CaregiverProfile (1:1)"
    PatientProfile ||--o{ PatientCaregiver : "has assigned (1:N)"
    CaregiverProfile ||--o{ PatientCaregiver : "linked to (1:N)"
    PatientProfile ||--o{ Medicine : "takes (1:N)"
    PatientProfile ||--o{ Prescription : "uploads (1:N)"
    PatientProfile ||--o{ MedicationHistory : "tracks dosage (1:N)"
    Medicine ||--o{ MedicationSchedule : "has schedule (1:N)"
    Medicine ||--o{ MedicationHistory : "recorded in history (1:N)"
```

---

## Environment Variables

Create a `.env` file in the root directory (based on `.env.example`):
```ini
SECRET_KEY=django-insecure-your-secret-key-goes-here
DEBUG=True
ALLOWED_HOSTS=localhost,127.0.0.1

# PostgreSQL Settings (Defaults to SQLite in local development if blank)
DB_NAME=pillsync
DB_USER=postgres
DB_PASSWORD=your_password
DB_HOST=127.0.0.1
DB_PORT=5432
```

---

## Installation & Setup

1. **Setup Virtual Environment & Install Dependencies**:
   ```bash
   python -m venv venv
   .\venv\Scripts\activate
   pip install django djangorestframework djangorestframework-simplejwt django-oauth-toolkit django-environ psycopg2-binary
   ```

2. **Generate and Apply Migrations**:
   ```bash
   python manage.py makemigrations accounts medication
   python manage.py migrate
   ```

3. **Create Superuser (for Django Admin verification)**:
   ```bash
   python manage.py createsuperuser
   ```

4. **Start Development Server**:
   ```bash
   python manage.py runserver
   ```

---

## Running Automated & Verification Tests

### Automated Unit Tests
To run Django's native unit tests (verifies registration rules, JWT login/refresh, change password, password reset, and logout token invalidation):
```bash
python manage.py test
```

### End-to-End API Verification Command
We provide a custom Django management command that programmatically issues requests simulating every endpoint, printing detailed JSON payloads, headers, and status codes. Run it using:
```bash
python manage.py verify_api
```
This script acts as the source of truth for checking API compliance!
