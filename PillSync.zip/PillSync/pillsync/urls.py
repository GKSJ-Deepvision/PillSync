from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),
    # Accounts/Authentication URLs
    path('api/auth/', include('accounts.urls')),
    # OAuth2 URLs
    path('api/oauth/', include('oauth2_provider.urls', namespace='oauth2_provider')),
]
