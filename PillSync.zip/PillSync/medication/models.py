from django.db import models
from accounts.models import PatientProfile

class Medicine(models.Model):
    patient = models.ForeignKey(PatientProfile, on_delete=models.CASCADE, related_name='medicines')
    medicine_name = models.CharField(max_length=255)
    dosage = models.CharField(max_length=100)
    quantity = models.IntegerField()
    frequency = models.CharField(max_length=100)
    start_date = models.DateField()
    end_date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.medicine_name} - {self.patient.user.username}"


class MedicationSchedule(models.Model):
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE, related_name='schedules')
    scheduled_time = models.TimeField()
    frequency = models.CharField(max_length=100)
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"Schedule for {self.medicine.medicine_name} at {self.scheduled_time}"


class Prescription(models.Model):
    patient = models.ForeignKey(PatientProfile, on_delete=models.CASCADE, related_name='prescriptions')
    file_path = models.CharField(max_length=500)
    prescription_date = models.DateField()
    expiry_date = models.DateField(null=True, blank=True)
    uploaded_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"Prescription ({self.prescription_date}) - {self.patient.user.username}"


class MedicationHistory(models.Model):
    STATUS_CHOICES = (
        ('TAKEN', 'Taken'),
        ('MISSED', 'Missed'),
        ('SKIPPED', 'Skipped'),
    )
    
    medicine = models.ForeignKey(Medicine, on_delete=models.CASCADE, related_name='history_records')
    patient = models.ForeignKey(PatientProfile, on_delete=models.CASCADE, related_name='history_records')
    scheduled_time = models.DateTimeField()
    taken_time = models.DateTimeField(null=True, blank=True)
    status = models.CharField(max_length=50, choices=STATUS_CHOICES)
    notes = models.TextField(null=True, blank=True)

    def __str__(self):
        return f"History: {self.medicine.medicine_name} ({self.status}) at {self.scheduled_time}"
