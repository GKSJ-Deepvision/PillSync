from django.contrib import admin
from .models import Medicine, MedicationSchedule, Prescription, MedicationHistory

admin.site.register(Medicine)
admin.site.register(MedicationSchedule)
admin.site.register(Prescription)
admin.site.register(MedicationHistory)
