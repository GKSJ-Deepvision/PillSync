from django.urls import reverse
from django.contrib.auth import get_user_model
from django.contrib.auth.tokens import default_token_generator
from django.utils.http import urlsafe_base64_encode
from django.utils.encoding import force_bytes
from rest_framework import status
from rest_framework.test import APITestCase
from accounts.models import PatientProfile, CaregiverProfile

User = get_user_model()

class AuthenticationTests(APITestCase):

    def setUp(self):
        # Create a test user for auth testing
        self.patient_password = "PatientPassword@123"
        self.patient_user = User.objects.create_user(
            username="testpatient",
            email="patient@example.com",
            password=self.patient_password,
            first_name="John",
            last_name="Patient",
            phone_number="1234567890",
            role="PATIENT"
        )
        # Verify profile auto-created in model save/create
        PatientProfile.objects.get_or_create(user=self.patient_user)

        self.caregiver_password = "CaregiverPassword@123"
        self.caregiver_user = User.objects.create_user(
            username="testcaregiver",
            email="caregiver@example.com",
            password=self.caregiver_password,
            first_name="Jane",
            last_name="Caregiver",
            phone_number="0987654321",
            role="CAREGIVER"
        )
        CaregiverProfile.objects.get_or_create(user=self.caregiver_user)

    def test_user_registration_patient_success(self):
        """Test registering a patient successfully."""
        url = reverse('auth_register')
        data = {
            "username": "newpatient",
            "email": "newpatient@example.com",
            "password": "NewPatient@12345",
            "first_name": "New",
            "last_name": "Patient",
            "phone_number": "5551234567",
            "role": "PATIENT"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['username'], 'newpatient')
        self.assertEqual(response.data['role'], 'PATIENT')
        
        # Verify user and patient profile were created in the DB
        user = User.objects.get(username='newpatient')
        self.assertTrue(PatientProfile.objects.filter(user=user).exists())
        self.assertFalse(CaregiverProfile.objects.filter(user=user).exists())

    def test_user_registration_caregiver_success(self):
        """Test registering a caregiver successfully."""
        url = reverse('auth_register')
        data = {
            "username": "newcaregiver",
            "email": "newcaregiver@example.com",
            "password": "NewCaregiver@12345",
            "first_name": "New",
            "last_name": "Caregiver",
            "phone_number": "5557654321",
            "role": "CAREGIVER"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['role'], 'CAREGIVER')
        
        # Verify caregiver profile created
        user = User.objects.get(username='newcaregiver')
        self.assertTrue(CaregiverProfile.objects.filter(user=user).exists())
        self.assertFalse(PatientProfile.objects.filter(user=user).exists())

    def test_registration_validation_errors(self):
        """Test registration fails with duplicate fields, weak password, or invalid email."""
        url = reverse('auth_register')
        
        # Duplicate Username
        data = {
            "username": "testpatient",
            "email": "another@example.com",
            "password": "StrongPassword@123",
            "first_name": "First",
            "last_name": "Last"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('username', response.data)

        # Duplicate Email
        data = {
            "username": "uniqueusername",
            "email": "patient@example.com",
            "password": "StrongPassword@123",
            "first_name": "First",
            "last_name": "Last"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('email', response.data)

        # Weak Password (minimum length 8 config)
        data = {
            "username": "uniqueusername",
            "email": "unique@example.com",
            "password": "short",
            "first_name": "First",
            "last_name": "Last"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)
        self.assertIn('password', response.data)

    def test_login_jwt_success(self):
        """Test getting JWT tokens on valid login."""
        url = reverse('token_obtain_pair')
        data = {
            "username": "testpatient",
            "password": self.patient_password
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)
        self.assertIn('refresh', response.data)

    def test_login_invalid_credentials(self):
        """Test login fails with incorrect password."""
        url = reverse('token_obtain_pair')
        data = {
            "username": "testpatient",
            "password": "WrongPassword@123"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_jwt_token_refresh(self):
        """Test refreshing JWT access token."""
        # 1. Login to get tokens
        login_url = reverse('token_obtain_pair')
        login_data = {
            "username": "testpatient",
            "password": self.patient_password
        }
        login_response = self.client.post(login_url, login_data, format='json')
        refresh_token = login_response.data['refresh']

        # 2. Refresh access token
        refresh_url = reverse('token_refresh')
        refresh_data = {
            "refresh": refresh_token
        }
        response = self.client.post(refresh_url, refresh_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('access', response.data)

    def test_jwt_token_refresh_invalid(self):
        """Test refreshing access token fails with invalid refresh token."""
        url = reverse('token_refresh')
        data = {
            "refresh": "invalid_refresh_token_here"
        }
        response = self.client.post(url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_protected_me_endpoint_success(self):
        """Test fetching current user details with valid JWT."""
        # 1. Login to get token
        login_url = reverse('token_obtain_pair')
        login_data = {
            "username": "testpatient",
            "password": self.patient_password
        }
        login_response = self.client.post(login_url, login_data, format='json')
        access_token = login_response.data['access']

        # 2. Access me endpoint
        me_url = reverse('auth_me')
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {access_token}')
        response = self.client.get(me_url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['username'], 'testpatient')
        self.assertEqual(response.data['email'], 'patient@example.com')

    def test_protected_me_endpoint_unauthorized(self):
        """Test fetching current user details without token fails."""
        url = reverse('auth_me')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_change_password_success(self):
        """Test password change for authenticated user."""
        # 1. Login to get token
        login_url = reverse('token_obtain_pair')
        login_data = {
            "username": "testpatient",
            "password": self.patient_password
        }
        login_response = self.client.post(login_url, login_data, format='json')
        access_token = login_response.data['access']

        # 2. Change password
        change_url = reverse('auth_change_password')
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {access_token}')
        change_data = {
            "old_password": self.patient_password,
            "new_password": "NewStrongPassword@12345"
        }
        response = self.client.post(change_url, change_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # 3. Verify old password no longer works
        login_data["password"] = self.patient_password
        self.client.credentials() # Reset headers
        fail_response = self.client.post(login_url, login_data, format='json')
        self.assertEqual(fail_response.status_code, status.HTTP_401_UNAUTHORIZED)

        # 4. Verify new password works
        login_data["password"] = "NewStrongPassword@12345"
        success_response = self.client.post(login_url, login_data, format='json')
        self.assertEqual(success_response.status_code, status.HTTP_200_OK)

    def test_logout_blacklist(self):
        """Test logout blacklists refresh token."""
        # 1. Login to get tokens
        login_url = reverse('token_obtain_pair')
        login_data = {
            "username": "testpatient",
            "password": self.patient_password
        }
        login_response = self.client.post(login_url, login_data, format='json')
        access_token = login_response.data['access']
        refresh_token = login_response.data['refresh']

        # 2. Logout
        logout_url = reverse('auth_logout')
        self.client.credentials(HTTP_AUTHORIZATION=f'Bearer {access_token}')
        logout_data = {
            "refresh": refresh_token
        }
        response = self.client.post(logout_url, logout_data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)

        # 3. Verify that trying to use the refresh token again fails
        refresh_url = reverse('token_refresh')
        refresh_data = {
            "refresh": refresh_token
        }
        self.client.credentials() # Reset headers
        fail_response = self.client.post(refresh_url, refresh_data, format='json')
        self.assertEqual(fail_response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_password_reset_flow(self):
        """Test password reset workflow."""
        # 1. Request reset link
        reset_req_url = reverse('auth_password_reset')
        data = {
            "email": "patient@example.com"
        }
        response = self.client.post(reset_req_url, data, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        
        # In development, the view returns the token info
        uidb64 = response.data['dev_info']['uidb64']
        token = response.data['dev_info']['token']

        # 2. Confirm reset
        reset_confirm_url = reverse('auth_password_reset_confirm')
        confirm_data = {
            "uidb64": uidb64,
            "token": token,
            "new_password": "NewResetPassword@123"
        }
        confirm_response = self.client.post(reset_confirm_url, confirm_data, format='json')
        self.assertEqual(confirm_response.status_code, status.HTTP_200_OK)

        # 3. Verify login works with new password
        login_url = reverse('token_obtain_pair')
        login_data = {
            "username": "testpatient",
            "password": "NewResetPassword@123"
        }
        login_response = self.client.post(login_url, login_data, format='json')
        self.assertEqual(login_response.status_code, status.HTTP_200_OK)
