from django.contrib import admin
from django.contrib.auth.admin import UserAdmin
from .models import User, PatientProfile, CaregiverProfile, PatientCaregiver

class CustomUserAdmin(UserAdmin):
    model = User
    list_display = ['username', 'email', 'first_name', 'last_name', 'role', 'is_staff']
    fieldsets = UserAdmin.fieldsets + (
        (None, {'fields': ('phone_number', 'role')}),
    )
    add_fieldsets = UserAdmin.add_fieldsets + (
        (None, {'fields': ('phone_number', 'role')}),
    )

admin.site.register(User, CustomUserAdmin)
admin.site.register(PatientProfile)
admin.site.register(CaregiverProfile)
admin.site.register(PatientCaregiver)
