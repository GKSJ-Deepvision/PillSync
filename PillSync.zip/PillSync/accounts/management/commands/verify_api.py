import json
from django.core.management.base import BaseCommand
from rest_framework.test import APIClient
from django.contrib.auth import get_user_model
from accounts.models import PatientProfile, CaregiverProfile

User = get_user_model()

class Command(BaseCommand):
    help = 'Runs verification testing against all authentication APIs'

    def handle(self, *args, **options):
        client = APIClient()
        self.stdout.write(self.style.MIGRATE_HEADING("=== PILlSYNC AUTHENTICATION & DATABASE SCHEMA VERIFICATION ==="))

        # Cleanup existing test users to prevent duplicate errors from past runs
        User.objects.filter(username__in=['verify_patient', 'verify_caregiver', 'dup_user']).delete()

        # ----------------------------------------------------
        # 1. USER REGISTRATION
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n1. TESTING USER REGISTRATION"))
        
        # 1A. Patient Registration (Success)
        reg_patient_data = {
            "username": "verify_patient",
            "email": "verify_patient@example.com",
            "password": "VerifyPatient@123",
            "first_name": "Verify",
            "last_name": "Patient",
            "phone_number": "1234567890",
            "role": "PATIENT"
        }
        self.stdout.write(f"Request: POST /api/auth/register/ with body:\n{json.dumps(reg_patient_data, indent=2)}")
        response = client.post('/api/auth/register/', reg_patient_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        # Verify db profile auto-creation
        user = User.objects.get(username='verify_patient')
        has_pat_prof = PatientProfile.objects.filter(user=user).exists()
        self.stdout.write(self.style.SUCCESS(f"Verification: Patient Profile automatically created in database? {has_pat_prof}"))

        # 1B. Caregiver Registration (Success)
        reg_caregiver_data = {
            "username": "verify_caregiver",
            "email": "verify_caregiver@example.com",
            "password": "VerifyCaregiver@123",
            "first_name": "Verify",
            "last_name": "Caregiver",
            "phone_number": "0987654321",
            "role": "CAREGIVER"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/register/ with body:\n{json.dumps(reg_caregiver_data, indent=2)}")
        response = client.post('/api/auth/register/', reg_caregiver_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        # Verify db profile auto-creation
        user_cg = User.objects.get(username='verify_caregiver')
        has_cg_prof = CaregiverProfile.objects.filter(user=user_cg).exists()
        self.stdout.write(self.style.SUCCESS(f"Verification: Caregiver Profile automatically created in database? {has_cg_prof}"))

        # 1C. Fail Registration: Duplicate Username
        dup_user_data = {
            "username": "verify_patient",
            "email": "different_email@example.com",
            "password": "SomePassword@123",
            "first_name": "Dup",
            "last_name": "User",
            "role": "PATIENT"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/register/ (Duplicate Username) with body:\n{json.dumps(dup_user_data, indent=2)}")
        response = client.post('/api/auth/register/', dup_user_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # 1D. Fail Registration: Duplicate Email
        dup_email_data = {
            "username": "dup_user",
            "email": "verify_patient@example.com",
            "password": "SomePassword@123",
            "first_name": "Dup",
            "last_name": "User",
            "role": "PATIENT"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/register/ (Duplicate Email) with body:\n{json.dumps(dup_email_data, indent=2)}")
        response = client.post('/api/auth/register/', dup_email_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # 1E. Fail Registration: Weak Password
        weak_pass_data = {
            "username": "dup_user",
            "email": "new_unique@example.com",
            "password": "short",
            "first_name": "Dup",
            "last_name": "User",
            "role": "PATIENT"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/register/ (Weak Password) with body:\n{json.dumps(weak_pass_data, indent=2)}")
        response = client.post('/api/auth/register/', weak_pass_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # ----------------------------------------------------
        # 2. JWT LOGIN
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n2. TESTING LOGIN WITH JWT"))
        
        login_data = {
            "username": "verify_patient",
            "password": "VerifyPatient@123"
        }
        self.stdout.write(f"Request: POST /api/auth/login/ with body:\n{json.dumps(login_data, indent=2)}")
        response = client.post('/api/auth/login/', login_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        access_token = response.data.get('access')
        refresh_token = response.data.get('refresh')

        # Fail Login: Invalid Credentials
        invalid_login_data = {
            "username": "verify_patient",
            "password": "WrongPassword@123"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/login/ (Wrong Password) with body:\n{json.dumps(invalid_login_data, indent=2)}")
        response = client.post('/api/auth/login/', invalid_login_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # ----------------------------------------------------
        # 3. JWT REFRESH
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n3. TESTING JWT REFRESH"))
        
        refresh_data = {
            "refresh": refresh_token
        }
        self.stdout.write(f"Request: POST /api/auth/token/refresh/ with body:\n{json.dumps(refresh_data, indent=2)}")
        response = client.post('/api/auth/token/refresh/', refresh_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        new_access_token = response.data.get('access')

        # Fail Refresh: Invalid Token
        invalid_refresh_data = {
            "refresh": "invalid_refresh_token_string"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/token/refresh/ (Invalid Token) with body:\n{json.dumps(invalid_refresh_data, indent=2)}")
        response = client.post('/api/auth/token/refresh/', invalid_refresh_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # ----------------------------------------------------
        # 4. PROTECTED ME ENDPOINT
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n4. TESTING PROTECTED ME ENDPOINT"))
        
        # 4A. Call without authorization headers
        self.stdout.write("Request: GET /api/auth/me/ (No credentials)")
        client.credentials() # Reset headers
        response = client.get('/api/auth/me/')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # 4B. Call with valid access token
        self.stdout.write("\nRequest: GET /api/auth/me/ (With Bearer Access Token)")
        client.credentials(HTTP_AUTHORIZATION=f'Bearer {new_access_token}')
        response = client.get('/api/auth/me/')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # ----------------------------------------------------
        # 5. CHANGE PASSWORD
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n5. TESTING CHANGE PASSWORD"))
        
        change_pass_data = {
            "old_password": "VerifyPatient@123",
            "new_password": "NewPatientPassword@123"
        }
        self.stdout.write(f"Request: POST /api/auth/change-password/ with body:\n{json.dumps(change_pass_data, indent=2)}")
        response = client.post('/api/auth/change-password/', change_pass_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # Verify old password fails login now
        client.credentials() # Reset headers
        self.stdout.write("\nVerification: Attempting login with old password after change...")
        response = client.post('/api/auth/login/', {"username": "verify_patient", "password": "VerifyPatient@123"}, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # Verify new password logins successfully
        self.stdout.write("\nVerification: Attempting login with new password after change...")
        response = client.post('/api/auth/login/', {"username": "verify_patient", "password": "NewPatientPassword@123"}, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        # Capture current token for subsequent steps
        new_access_token = response.data.get('access')
        refresh_token = response.data.get('refresh')

        # ----------------------------------------------------
        # 6. PASSWORD RESET WORKFLOW
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n6. TESTING PASSWORD RESET WORKFLOW"))
        
        # 6A. Request Reset Link
        reset_req_data = {
            "email": "verify_patient@example.com"
        }
        self.stdout.write(f"Request: POST /api/auth/password-reset/ with body:\n{json.dumps(reset_req_data, indent=2)}")
        response = client.post('/api/auth/password-reset/', reset_req_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        uidb64 = response.data['dev_info']['uidb64']
        token = response.data['dev_info']['token']

        # 6B. Confirm password reset
        reset_confirm_data = {
            "uidb64": uidb64,
            "token": token,
            "new_password": "ResetPatientPassword@123"
        }
        self.stdout.write(f"\nRequest: POST /api/auth/password-reset/confirm/ with body:\n{json.dumps(reset_confirm_data, indent=2)}")
        response = client.post('/api/auth/password-reset/confirm/', reset_confirm_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # Verify login works with reset password
        self.stdout.write("\nVerification: Attempting login with reset password...")
        response = client.post('/api/auth/login/', {"username": "verify_patient", "password": "ResetPatientPassword@123"}, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")
        
        new_access_token = response.data.get('access')
        refresh_token = response.data.get('refresh')

        # ----------------------------------------------------
        # 7. LOGOUT / TOKEN BLACKLISTING
        # ----------------------------------------------------
        self.stdout.write(self.style.WARNING("\n7. TESTING LOGOUT / TOKEN INVALIDATION"))
        
        logout_data = {
            "refresh": refresh_token
        }
        client.credentials(HTTP_AUTHORIZATION=f'Bearer {new_access_token}')
        self.stdout.write(f"Request: POST /api/auth/logout/ with body:\n{json.dumps(logout_data, indent=2)}")
        response = client.post('/api/auth/logout/', logout_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        # Verify refresh token is now invalid/blacklisted
        refresh_data = {
            "refresh": refresh_token
        }
        client.credentials() # Reset headers
        self.stdout.write("\nVerification: Attempting to refresh access token using the blacklisted refresh token...")
        response = client.post('/api/auth/token/refresh/', refresh_data, format='json')
        self.stdout.write(f"Response (Status {response.status_code}):\n{json.dumps(response.data, indent=2)}")

        self.stdout.write(self.style.SUCCESS("\n=== ALL AUTHENTICATION API TEST CASES SUCCESSFULLY VERIFIED ==="))
